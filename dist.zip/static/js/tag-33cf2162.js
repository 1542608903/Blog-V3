import{a2 as a}from"./index-5f289e8b.js";const o=()=>new Promise((t,r)=>{a.get("/api/tag/getTagDictionary",{}).then(e=>{t(e)})});export{o as g};
